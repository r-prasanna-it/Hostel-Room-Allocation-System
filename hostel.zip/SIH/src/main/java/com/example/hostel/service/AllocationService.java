package com.example.hostel.service;

import com.example.hostel.model.Room;
import com.example.hostel.model.Student;

import java.io.*;
import java.util.*;

public class AllocationService implements Serializable {
    private static final long serialVersionUID = 1L;

    private List<Room> rooms = new ArrayList<>();
    private List<Student> students = new ArrayList<>();

    public enum Filter { ANY, SAME_COURSE, SAME_YEAR, SAME_COURSE_AND_YEAR }

    public AllocationService() {
        // Default sample rooms
        rooms.add(new Room(101, 2));
        rooms.add(new Room(102, 2));
        rooms.add(new Room(103, 3));
    }

    // Default constructor for serialization
    public AllocationService(List<Room> rooms, List<Student> students) {
        this.rooms = rooms;
        this.students = students;
    }

    public String allocateRoom(Student student, Filter filter) {
        for (Room r : rooms) {
            if (r.isAvailable() && matchesFilter(r, student, filter)) {
                r.allotStudent();
                student.setRoomId(r.getRoomId());
                students.add(student);
                return "Student " + student.getName() + " allotted to Room " + r.getRoomId();
            }
        }
        // fallback to ANY available room
        for (Room r : rooms) {
            if (r.isAvailable()) {
                r.allotStudent();
                student.setRoomId(r.getRoomId());
                students.add(student);
                return "Student " + student.getName() + " allotted to Room " + r.getRoomId() + " (fallback)";
            }
        }
        return "No rooms available!";
    }

    private boolean matchesFilter(Room r, Student s, Filter f) {
        List<Student> inRoom = getStudentsInRoom(r.getRoomId());
        switch (f) {
            case SAME_COURSE:
                return inRoom.stream().allMatch(st -> st.getCourse().equalsIgnoreCase(s.getCourse()));
            case SAME_YEAR:
                return inRoom.stream().allMatch(st -> st.getYear() == s.getYear());
            case SAME_COURSE_AND_YEAR:
                return inRoom.stream().allMatch(st ->
                        st.getCourse().equalsIgnoreCase(s.getCourse()) && st.getYear() == s.getYear());
            default:
                return true;
        }
    }

    public List<Student> getStudents() { return students; }
    public List<Room> getRooms() { return rooms; }

    public List<Student> getStudentsInRoom(int roomId) {
        List<Student> list = new ArrayList<>();
        for (Student s : students) {
            if (s.getRoomId() == roomId) {
                list.add(s);
            }
        }
        return list;
    }

    public void addRoom(Room room) { rooms.add(room); }

    // -------- FILE I/O ----------
    public void saveData(String filename) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(rooms);
            oos.writeObject(students);
        }
    }

    @SuppressWarnings("unchecked")
    public void loadData(String filename) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            rooms = (List<Room>) ois.readObject();
            students = (List<Student>) ois.readObject();
        }
    }
}
