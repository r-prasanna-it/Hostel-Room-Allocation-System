package com.example.hostel;

import com.example.hostel.model.Student;

public class TestStudent {
    public static void main(String[] args) {
        Student s = new Student(1, "Alice", "CS", 2);
        System.out.println("ID: " + s.getId());
        System.out.println("Name: " + s.getName());
        System.out.println("Course: " + s.getCourse());
        System.out.println("Year: " + s.getYear());
        System.out.println("Room ID: " + s.getRoomId());
    }
}