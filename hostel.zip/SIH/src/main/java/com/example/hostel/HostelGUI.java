package com.example.hostel;

import com.example.hostel.model.Room;
import com.example.hostel.model.Student;
import com.example.hostel.service.AllocationService;
import java.awt.*;
import javax.swing.*;

public class HostelGUI extends JFrame {
    private AllocationService service;

    private JTextArea directoryArea, occupancyArea;
    private JTextField nameField, courseField, yearField;
    private JTextField roomIdField, capacityField;
    private JComboBox<AllocationService.Filter> filterBox;

    public HostelGUI() {
        service = new AllocationService();

        setTitle("Hostel Room Allocation System");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.add("Room Directory", createRoomDirectoryPanel());
        tabbedPane.add("Allocation Engine", createAllocationPanel());
        tabbedPane.add("Warden Panel", createWardenPanel());
        tabbedPane.add("Occupancy Report", createOccupancyPanel());

        add(tabbedPane);
    }

    // ---- Room Directory ----
    private JPanel createRoomDirectoryPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JButton refreshBtn = new JButton("Refresh Rooms");
        directoryArea = new JTextArea();
        directoryArea.setEditable(false);

        refreshBtn.addActionListener(e -> showRooms());

        panel.add(refreshBtn, BorderLayout.NORTH);
        panel.add(new JScrollPane(directoryArea), BorderLayout.CENTER);
        return panel;
    }

    private void showRooms() {
        directoryArea.setText("Room Directory:\n");
        for (Room r : service.getRooms()) {
            directoryArea.append("Room " + r.getRoomId() + " | Capacity: " + r.getCapacity()
                    + " | Occupied: " + r.getOccupied() + "\n");
        }
    }

    // ---- Allocation Engine ----
    private JPanel createAllocationPanel() {
        JPanel panel = new JPanel(new GridLayout(6, 2));

        panel.add(new JLabel("Name:"));
        nameField = new JTextField();
        panel.add(nameField);

        panel.add(new JLabel("Course:"));
        courseField = new JTextField();
        panel.add(courseField);

        panel.add(new JLabel("Year:"));
        yearField = new JTextField();
        panel.add(yearField);

        panel.add(new JLabel("Preference:"));
        filterBox = new JComboBox<>(AllocationService.Filter.values());
        panel.add(filterBox);

        JButton allocateBtn = new JButton("Allocate Room");
        JTextArea resultArea = new JTextArea();
        resultArea.setEditable(false);

        allocateBtn.addActionListener(e -> {
            try {
                String name = nameField.getText().trim();
                String course = courseField.getText().trim();
                String yearStr = yearField.getText().trim();
                if (name.isEmpty() || course.isEmpty() || yearStr.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please fill all fields.");
                    return;
                }
                int year = Integer.parseInt(yearStr);
                AllocationService.Filter filter =
                        (AllocationService.Filter) filterBox.getSelectedItem();

                Student s = new Student((int)(Math.random()*1000), name, course, year);
                String result = service.allocateRoom(s, filter);
                resultArea.setText(result);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Year must be a number.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        panel.add(allocateBtn);
        panel.add(new JScrollPane(resultArea));
        return panel;
    }

    // ---- Warden Panel ----
    private JPanel createWardenPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 2));

        panel.add(new JLabel("Room ID:"));
        roomIdField = new JTextField();
        panel.add(roomIdField);

        panel.add(new JLabel("Capacity:"));
        capacityField = new JTextField();
        panel.add(capacityField);

        JButton addRoomBtn = new JButton("Add Room");
        JButton saveBtn = new JButton("Save Data");
        JButton loadBtn = new JButton("Load Data");
        JTextArea resultArea = new JTextArea();
        resultArea.setEditable(false);

        addRoomBtn.addActionListener(e -> {
            try {
                String roomIdStr = roomIdField.getText().trim();
                String capacityStr = capacityField.getText().trim();
                if (roomIdStr.isEmpty() || capacityStr.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please fill all fields.");
                    return;
                }
                int roomId = Integer.parseInt(roomIdStr);
                int capacity = Integer.parseInt(capacityStr);

                service.addRoom(new Room(roomId, capacity));
                resultArea.setText("Room " + roomId + " added successfully!");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Room ID and Capacity must be numbers.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        saveBtn.addActionListener(e -> {
            try {
                service.saveData("hostel_data.dat");
                resultArea.setText("Data saved successfully!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Save Error: " + ex.getMessage());
            }
        });

        loadBtn.addActionListener(e -> {
            try {
                service.loadData("hostel_data.dat");
                resultArea.setText("Data loaded successfully!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Load Error: " + ex.getMessage());
            }
        });

        panel.add(addRoomBtn);
        panel.add(saveBtn);
        panel.add(loadBtn);
        panel.add(new JScrollPane(resultArea));

        return panel;
    }

    // ---- Occupancy Report ----
    private JPanel createOccupancyPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        JButton refreshBtn = new JButton("View Occupancy");
        occupancyArea = new JTextArea();
        occupancyArea.setEditable(false);

        refreshBtn.addActionListener(e -> showOccupancy());

        panel.add(refreshBtn, BorderLayout.NORTH);
        panel.add(new JScrollPane(occupancyArea), BorderLayout.CENTER);
        return panel;
    }

    private void showOccupancy() {
        occupancyArea.setText("Current Occupancy:\n");
        for (Student s : service.getStudents()) {
            occupancyArea.append(s.getName() + " (" + s.getCourse() + ", Year " + s.getYear()
                    + ") -> Room " + s.getRoomId() + "\n");
        }
    }

    // ---- Main ----
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new HostelGUI().setVisible(true));
    }
}
