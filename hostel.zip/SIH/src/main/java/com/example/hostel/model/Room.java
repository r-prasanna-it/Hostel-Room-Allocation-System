package com.example.hostel.model;

import java.io.Serializable;

public class Room implements Serializable {
    private static final long serialVersionUID = 1L;
    private int roomId;
    private int capacity;
    private int occupied;

    public Room() {}

    public Room(int roomId, int capacity) {
        this.roomId = roomId;
        this.capacity = capacity;
        this.occupied = 0;
    }

    public int getRoomId() { return roomId; }
    public int getCapacity() { return capacity; }
    public int getOccupied() { return occupied; }
    public void setOccupied(int occupied) { this.occupied = occupied; }

    public boolean isAvailable() {
        return occupied < capacity;
    }

    public void allotStudent() {
        if (isAvailable()) {
            occupied++;
        }
    }
}
